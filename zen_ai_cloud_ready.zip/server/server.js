import express from "express";
import multer from "multer";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
if(!process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY is not set");

const __filename=fileURLToPath(import.meta.url);
const __dirname=path.dirname(__filename);
const app=express();
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:8*1024*1024}});
const openai=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
const CHAT_MODEL_MAP={
  "gpt-5.6-luna": process.env.OPENAI_CHAT_MODEL || "gpt-5",
  "gpt-5.4-mini": process.env.OPENAI_MINI_MODEL || "gpt-5-mini"
};

app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"../public")));
app.get("/health",(req,res)=>res.json({ok:true}));

app.post("/api/chat",async(req,res)=>{
  try{
    const {model,message,history=[]}=req.body;
    const allowed=Object.keys(CHAT_MODEL_MAP);
    const selected=allowed.includes(model)?model:"gpt-5.6-luna";
    res.setHeader("Content-Type","text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control","no-cache, no-transform");
    res.setHeader("Connection","keep-alive");

    const input=[...history.slice(-20),{role:"user",content:String(message||"")}];
    const stream=await openai.responses.create({
      model:CHAT_MODEL_MAP[selected],
      input,
      stream:true
    });
    for await(const event of stream){
      if(event.type==="response.output_text.delta"){
        res.write(`data: ${JSON.stringify({token:event.delta})}\n\n`);
      }
    }
    res.write("data: [DONE]\n\n");
    res.end();
  }catch(e){
    if(!res.headersSent) res.status(500).send(e.message);
    else {res.write(`data: ${JSON.stringify({error:e.message})}\n\n`);res.end();}
  }
});

app.post("/api/images",upload.single("image"),async(req,res)=>{
  try{
    const prompt=String(req.body.prompt||"高品質な写真");
    let result;
    if(req.file){
      result=await openai.images.edit({
        model:"gpt-image-2",
        image:new File([req.file.buffer],req.file.originalname,{type:req.file.mimetype}),
        prompt
      });
    }else{
      result=await openai.images.generate({model:"gpt-image-2",prompt});
    }
    const item=result.data?.[0];
    if(!item) throw new Error("画像生成結果がありません");
    res.json({url:item.url||`data:image/png;base64,${item.b64_json}`});
  }catch(e){res.status(500).send(e.message)}
});

app.listen(process.env.PORT||3000,()=>console.log("ZEN AI running on http://localhost:"+(process.env.PORT||3000)));
