# ZEN AI — 起動手順

## 1. Node.jsを入れる
Node.jsのLTS版を公式サイトからインストールしてください。

## 2. ターミナルでプロジェクトへ移動
```bash
cd zen_ai_app
```

## 3. 依存関係をインストール
```bash
npm install
```

## 4. APIキーを設定
`.env.example` を `.env` にコピーし、OpenAI APIキーを設定します。

```env
OPENAI_API_KEY=sk-xxxxxxxx
OPENAI_CHAT_MODEL=gpt-5
OPENAI_MINI_MODEL=gpt-5-mini
PORT=3000
```

**`.env` は絶対に公開・GitHubへアップロードしないでください。**

## 5. 起動
```bash
npm start
```

## 6. ブラウザ
`http://localhost:3000` を開きます。

## iPhone/iPadの場合
iOS単体ではこのNode.jsサーバーを普通のHTMLのように直接起動できません。
PC/Mac/VPS等でサーバーを起動し、同じネットワークならそのPCのIPアドレス:3000へアクセスできます。
インターネット公開する場合はHTTPS付きのサーバーへデプロイしてください。
